# Change Log Angle

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).



## [0.1.2] - 2023-10-17
- update readme.md


## [0.1.1] - 2023-01-23
- update GitHub actions
- update license 2023
- update readme
- add windrose() (2x)
- add example

## [0.1.0] - 2022-12-01 
- initial version

